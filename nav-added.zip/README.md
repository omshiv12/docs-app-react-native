# MINOR
Minor Project of third sem.
Using React native.
